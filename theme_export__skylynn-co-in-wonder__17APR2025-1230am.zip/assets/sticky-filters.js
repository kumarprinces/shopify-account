class StickyFilters extends HTMLElement {
  constructor() {
    super();
  }

  connectedCallback() {}
}

// Define the web component
customElements.define("sticky-filters", StickyFilters);
