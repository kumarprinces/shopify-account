class SlideshowSection extends Slider {}

customElements.define("slideshow-section", SlideshowSection);
